/*$(function () {
    char_7();
})*/
